from PyQt5.QtWidgets import QAction, QMessageBox
from qgis.core import *

class Sawitxercise:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_action = None
        self.dlg = None

    def initGui(self):
        from .sawitxercise_dialog import SawitxerciseDialog
        self.dlg = SawitxerciseDialog()
        self.plugin_action = QAction('Sawitxercise Plugin', self.iface.mainWindow())
        self.plugin_action.triggered.connect(self.run)
        self.iface.addPluginToMenu('Sawitxercise', self.plugin_action)
        self.iface.addToolBarIcon(self.plugin_action)

    def unload(self):
        self.iface.removePluginMenu('Sawitxercise', self.plugin_action)
        self.iface.removeToolBarIcon(self.plugin_action)

    def run(self):
        self.dlg.btnHitungLuas.clicked.connect(self.hitung_luas_layer)
        self.dlg.btnAmbilTitik.clicked.connect(self.ambil_koordinat)
        self.dlg.show()

    def hitung_luas_layer(self):
        layer = self.iface.activeLayer()
        if not layer or layer.geometryType() != 2:
            QMessageBox.warning(self.iface.mainWindow(), "Peringatan", "Pilih layer polygon terlebih dahulu.")
            return

        luas_total = 0
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom is not None:
                luas_total += geom.area()

        luas_hektar = luas_total / 10000
        self.dlg.labelHasilLuas.setText(f"Luas total: {luas_hektar:.2f} ha")

    def ambil_koordinat(self):
        layer = self.iface.activeLayer()
        if not layer or layer.geometryType() != 0:
            QMessageBox.warning(self.iface.mainWindow(), "Peringatan", "Pilih layer titik terlebih dahulu.")
            return

        selected = layer.selectedFeatures()
        if not selected:
            QMessageBox.information(self.iface.mainWindow(), "Info", "Pilih satu titik dulu di layer.")
            return

        geom = selected[0].geometry()
        if geom:
            point = geom.asPoint()
            self.dlg.labelKoordinat.setText(f"Latitude: {point.y():.6f}, Longitude: {point.x():.6f}")