def classFactory(iface):
    from .sawitxercise import Sawitxercise
    return Sawitxercise(iface)