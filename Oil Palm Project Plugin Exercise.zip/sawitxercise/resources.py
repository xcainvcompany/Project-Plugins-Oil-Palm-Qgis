# Compiled resources placeholder
