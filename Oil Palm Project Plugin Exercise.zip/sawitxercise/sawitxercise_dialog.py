from PyQt5 import uic
from PyQt5.QtWidgets import QDialog
import os

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'sawitxercise_dialog_base.ui'))

class SawitxerciseDialog(QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super(SawitxerciseDialog, self).__init__(parent)
        self.setupUi(self)